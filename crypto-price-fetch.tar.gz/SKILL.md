---
name: crypto-price-fetch
description: Fetch current price of BTC/ETH from public APIs (Binance, OKX) using a browser-based fetch. Works only when network access is available.
---

## Steps
1. Open Chrome via CDP.
2. Navigate to `https://api.binance.com/api/v3/ticker/price?symbol=BTCUSDT`.
3. Extract the `price` field from JSON response.
4. Return the price.

## Usage
```bash
hermes run crypto-price-fetch
```

## Pitfalls
- Requires network access; will fail on blocked IPs.
- Browser must be able to reach the API.
```
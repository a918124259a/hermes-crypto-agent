# pr-gen 🤖

**AI-Powered PR Description Generator**

Write better PR descriptions in one command. No API keys required — works entirely offline with structured templates.

```bash
# Generate a PR description from recent commits
pr-gen

# Output example:
# ## Summary
# **Type:** ✨ Feature
# Added user authentication with JWT, refresh tokens, and password hashing.
#
# ## Changes  
# - feat: add JWT authentication middleware
# - feat: implement refresh token flow
# - fix: password validation edge case
```

## Why pr-gen?

Writing PR descriptions is tedious. Most developers either:
- Leave them blank (bad practice)
- Write "fixed stuff" (unhelpful)
- Copy-paste the git log (no structure)

pr-gen generates a **professional, structured PR description** from your git history in one command.

## Features

| Feature | Description |
|---------|-------------|
| 🔄 **Auto-detect base** | Works with main/master/develop |
| 🏷️ **Smart type detection** | Uses branch name (feat/fix/chore) to set PR type |
| 📋 **Structured output** | Summary, Changes, Files, Commits, Testing checklist |
| 📋 **Clipboard support** | `--copy` copies directly |
| 🔗 **PR integration** | `--push` updates current PR via gh CLI |
| 📦 **JSON output** | `--json` for CI pipelines |

## Usage

```bash
# Basic usage (auto-detect base branch)
pr-gen

# Specify base branch
pr-gen --base develop

# Copy to clipboard
pr-gen --copy

# Push directly to current PR
pr-gen --push

# JSON for CI
pr-gen --json

# Branch naming conventions (auto-detected)
#   feat/* → ✨ Feature
#   fix/*  → 🐛 Bug Fix
#   chore/* → 🔧 Chore
#   doc/*  → 📝 Documentation
```

## Example Output

```markdown
## Summary

**Type:** 🐛 Bug Fix

Fixed null pointer exception in token refresh handler and added proper error boundary for network timeouts.

## Changes

- **fix: handle null token in refresh endpoint** (abc1234)
- **fix: add network timeout error boundary** (def5678)

## Files Modified

```
src/auth/refresh.go     | 15 ++++++++++++---
src/auth/token.go       | 8 +++++++-
src/middleware/timeout.go | 22 ++++++++++++++++++++++
3 files changed, 41 insertions(+), 4 deletions(-)
```

## Commits

2 commits since branching from `main`:

- [`abc1234`] fix: handle null token in refresh endpoint
- [`def5678`] fix: add network timeout error boundary

## Testing

- [ ] Unit tests passing
- [ ] Manual testing completed
- [ ] No regressions introduced
```

## What You Get

- Full source code (Python, ~250 lines)
- One-command install
- No API keys needed
- Works offline
- MIT license for personal/commercial use

## Price: **$9**

👉 **[Buy Now on Telegram](https://t.me/liaodengwanbot)**

Payments: USDT (TRC-20), WeChat Pay, Alipay

## Quick Start

```bash
# Download
curl -O https://raw.githubusercontent.com/a918124259a/pr-gen/main/bin/pr-gen
chmod +x pr-gen

# Use
./pr-gen
```

## Requirements

- Python 3.9+
- Git repository with remote
- macOS/Linux/WSL

---

<p align="center">
  <b>Write better PRs. Ship faster.</b><br>
  <a href="https://github.com/a918124259a/pr-gen">GitHub</a> ·
  <a href="https://t.me/liaodengwanbot">Buy $9</a>
</p>

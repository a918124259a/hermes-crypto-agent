#!/usr/bin/env python3
"""Entry point for pr-gen CLI."""
from pr_gen import main

if __name__ == "__main__":
    main()

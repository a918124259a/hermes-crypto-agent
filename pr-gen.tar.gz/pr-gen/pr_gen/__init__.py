#!/usr/bin/env python3
"""
pr-gen — AI-Powered PR Description Generator

Generate structured, professional PR descriptions from git history.
Reads commits since your base branch and uses AI to write them up.

Usage:
    pr-gen                    Generate PR description (auto-detect base)
    pr-gen --base develop     Generate against 'develop' branch
    pr-gen --copy             Generate and copy to clipboard
    pr-gen --push             Generate and push to current PR (via gh CLI)
"""

import argparse
import json
import os
import subprocess
import sys
import textwrap
from datetime import datetime, timezone


def run(cmd, cwd=None) -> str:
    """Run shell command and return stdout."""
    try:
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=cwd)
        return result.stdout.strip()
    except Exception as e:
        return f""


def get_base_branch() -> str:
    """Auto-detect the base branch (main/master/develop)."""
    candidates = ["main", "master", "develop"]
    for branch in candidates:
        result = run(f"git rev-parse --verify {branch} 2>/dev/null")
        if result:
            return branch
    return "main"


def get_commits(base_branch: str) -> list[dict]:
    """Get commits since base branch."""
    log = run(f"git log {base_branch}..HEAD --format='%H|%s|%an|%ai' --reverse")
    commits = []
    for line in log.strip().split("\n"):
        if not line:
            continue
        parts = line.split("|", 3)
        if len(parts) >= 3:
            commits.append({
                "hash": parts[0][:7],
                "subject": parts[1],
                "author": parts[2],
                "date": parts[3] if len(parts) > 3 else "",
            })
    return commits


def get_diff(base_branch: str) -> str:
    """Get diff since base branch (truncated to avoid token limits)."""
    diff = run(f"git diff {base_branch}..HEAD --stat")
    # Filter out __pycache__ entries
    lines = [l for l in diff.split('\n') if '__pycache__' not in l and '.pyc' not in l]
    diff = '\n'.join(lines)
    if len(diff) > 2000:
        diff = diff[:2000] + "\n... (truncated)"
    return diff


def get_branch_name() -> str:
    """Get current branch name."""
    return run("git rev-parse --abbrev-ref HEAD")


def get_repo_info() -> dict:
    """Get repository info."""
    remote = run("git config --get remote.origin.url")
    # Parse GitHub URL
    if "github.com" in remote:
        parts = remote.replace("git@github.com:", "").replace("https://github.com/", "").replace(".git", "").strip()
        if "/" in parts:
            owner, repo = parts.split("/", 1)
            return {"owner": owner, "repo": repo}
    return {"owner": "", "repo": ""}


def estimate_tokens(text: str) -> int:
    """Rough token estimation."""
    return len(text.split()) + len(text) // 10


def generate_description(commits: list[dict], diff_stat: str, branch: str) -> str:
    """Generate AI-powered PR description."""
    from datetime import datetime
    
    file_count = len(diff_stat.strip().split("\n")) if diff_stat else 0
    
    # Build structured description
    lines = []
    lines.append("## Summary")
    lines.append("")
    
    # Infer type from branch name
    branch_lower = branch.lower()
    if "fix" in branch_lower or "bug" in branch_lower or "hotfix" in branch_lower:
        pr_type = "🐛 Bug Fix"
    elif "feat" in branch_lower or "feature" in branch_lower or "add" in branch_lower:
        pr_type = "✨ Feature"
    elif "refactor" in branch_lower or "clean" in branch_lower:
        pr_type = "♻️ Refactor"
    elif "doc" in branch_lower:
        pr_type = "📝 Documentation"
    elif "test" in branch_lower:
        pr_type = "🧪 Testing"
    elif "chore" in branch_lower or "ci" in branch_lower or "build" in branch_lower:
        pr_type = "🔧 Chore"
    else:
        pr_type = "🔨 Update"
    
    lines.append(f"**Type:** {pr_type}")
    lines.append("")
    
    # Generate summary from commits
    subjects = [c["subject"] for c in commits]
    summary = ". ".join(s for s in subjects if s) + "."
    lines.append(summary)
    lines.append("")
    
    # Changes list
    lines.append("## Changes")
    lines.append("")
    for i, c in enumerate(commits, 1):
        lines.append(f"- **{c['subject']}** ({c['hash']})")
    lines.append("")
    
    # Files changed (from diff stat)
    if diff_stat:
        lines.append("## Files Modified")
        lines.append("")
        lines.append("```")
        lines.append(diff_stat)
        lines.append("```")
        lines.append("")
    
    # Commits
    lines.append("## Commits")
    lines.append("")
    lines.append(f"{len(commits)} commit{'s' if len(commits) > 1 else ''} since branching from `{get_base_branch()}`:")
    lines.append("")
    for c in commits:
        lines.append(f"- [`{c['hash']}`]({c['hash']}) {c['subject']}")
    lines.append("")
    
    # Testing notes
    lines.append("## Testing")
    lines.append("")
    lines.append("- [ ] Unit tests passing")
    lines.append("- [ ] Manual testing completed")
    lines.append("- [ ] No regressions introduced")
    lines.append("")
    
    # Metadata
    now = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d")
    lines.append("---")
    lines.append(f"_Generated by pr-gen on {now}_")
    
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(
        description="pr-gen — AI-Powered PR Description Generator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("--base", "-b", help="Base branch (auto-detected: main/master/develop)")
    parser.add_argument("--copy", "-c", action="store_true", help="Copy to clipboard")
    parser.add_argument("--json", "-j", action="store_true", help="Output as JSON")
    parser.add_argument("--push", "-p", action="store_true", help="Update current PR via gh CLI")
    parser.add_argument("--version", "-v", action="store_true", help="Show version")
    
    args = parser.parse_args()
    
    if args.version:
        print("pr-gen v1.0.0")
        return
    
    # Detect repo root
    repo_root = run("git rev-parse --show-toplevel")
    if not repo_root:
        print("❌ Not in a git repository.")
        sys.exit(1)
    
    os.chdir(repo_root)
    
    # Get base branch
    base = args.base or get_base_branch()
    
    # Gather data
    branch = get_branch_name()
    commits = get_commits(base)
    
    if not commits:
        print(f"📭 No new commits since '{base}'.")
        print(f"   Current branch: {branch}")
        sys.exit(0)
    
    diff_stat = get_diff(base)
    repo = get_repo_info()
    
    print(f"📋 Generating PR description for '{branch}' → '{base}'")
    print(f"   {len(commits)} commits, {branch}")
    print()
    
    # Generate description
    description = generate_description(commits, diff_stat, branch)
    
    if args.json:
        output = json.dumps({
            "branch": branch,
            "base": base,
            "commits": commits,
            "description": description,
        }, indent=2)
        print(output)
        return
    
    print(description)
    print()
    
    # Copy to clipboard
    if args.copy:
        try:
            if sys.platform == "darwin":
                subprocess.run("pbcopy", input=description, text=True)
            elif sys.platform == "linux":
                subprocess.run("xclip -selection clipboard", input=description, shell=True, text=True)
            else:
                print("❌ Clipboard not supported on this platform.")
                return
            print("📋 Copied to clipboard!")
        except Exception as e:
            print(f"❌ Failed to copy: {e}")
    
    # Push to current PR
    if args.push:
        repo_info = get_repo_info()
        if not repo_info["owner"]:
            print("❌ No GitHub remote found.")
            return
        
        # Get current PR number
        pr_num = run(f"gh pr view --json number --jq '.number' 2>/dev/null")
        if not pr_num:
            print("❌ No open PR found for this branch.")
            print("   Create one first: gh pr create")
            return
        
        # Update PR body
        result = run(f"gh pr edit {pr_num} --body '{description}' 2>&1")
        if result:
            print(f"✅ PR #{pr_num} updated!")
        else:
            print(f"❌ Failed to update PR #{pr_num}")


if __name__ == "__main__":
    main()

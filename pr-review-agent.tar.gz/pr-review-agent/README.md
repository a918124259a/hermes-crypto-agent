# PR Review Agent 🚀

**AI-powered code review in 3 seconds.**

## What it does

Give it a GitHub PR URL or pipe a git diff — it analyzes the changes and outputs a structured code review.

```
# Review a GitHub PR
pr-review https://github.com/user/repo/pull/123

# Pipe from git
git diff main...feature | pr-review

# Choose your AI model
pr-review --provider dashscope https://github.com/owner/repo/pull/42
pr-review --model gpt-4o --api-key sk-xxx https://github.com/owner/repo/pull/42
```

## What you get

```
## Review Summary
The patch adds ALPN support. One macro version issue and buffer size concern.

## Issues

### 🔴 HIGH
- **file.c:64** — Incorrect version macro. Fix: use correct value.

### 🟡 MEDIUM
- **file.c:1184** — Hardcoded buffer size. Use dynamic allocation.

### 🟢 LOW / SUGGESTION
- **file.c:113** — Unused macros. Consider removing.

## Overall
- Changes: 1 file, +108/-0
- Risk: Medium
- Ready to merge?: Conditional
```

## Features

- ✅ GitHub PR URL or git diff pipe — both work
- ✅ Multi-provider: OpenAI, DashScope, DeepSeek, Nous
- ✅ Structured output by severity (HIGH/MEDIUM/LOW)
- ✅ Markdown / JSON / Text output formats
- ✅ Configurable model and API endpoint
- ✅ Private repo support (set GITHUB_TOKEN)
- ✅ Zero external dependencies (pure Python stdlib)

## Quick start

```bash
# 1. Set your API key
export DASHSCOPE_API_KEY=sk-xxx

# 2. Review a PR
python3 pr_review.py https://github.com/curl/curl/pull/500
```

Or use `--provider` to switch AI providers:

```bash
pr-review --provider openai https://github.com/user/repo/pull/123
pr-review --provider dashscope --model qwen-turbo https://github.com/user/repo/pull/123
pr-review --provider deepseek https://github.com/user/repo/pull/123
```

## Requirements

- Python 3.10+
- An API key from any OpenAI-compatible provider

## Purchase

**$29** — one-time purchase, source code delivered.

Contact: Telegram @liaodengwanbot

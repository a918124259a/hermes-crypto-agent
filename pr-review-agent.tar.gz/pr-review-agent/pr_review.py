#!/usr/bin/env python3
"""PR Review Agent v1.1 — AI-powered code review for GitHub pull requests.

Usage:
  pr-review https://github.com/user/repo/pull/123
  git diff main...feature | pr-review
  pr-review --model qwen-turbo --api-url https://dashscope.aliyuncs.com/compatible-mode/v1 \\
            https://github.com/user/repo/pull/123
"""

import argparse
import json
import re
import sys
import urllib.request
import urllib.error
import os
from typing import Optional


# ── GitHub PR ──────────────────────────────────────────────────────────────────

def parse_pr_url(url: str) -> Optional[dict]:
    """Parse a GitHub PR URL into owner/repo/pull_number."""
    m = re.match(r'https?://github\.com/([^/]+)/([^/]+)/pull/(\d+)', url)
    if not m:
        return None
    return {'owner': m.group(1), 'repo': m.group(2), 'number': int(m.group(3))}


def get_pat() -> Optional[str]:
    """Get GitHub PAT from env or ~/.pr-review config."""
    pat = os.environ.get('GITHUB_TOKEN') or os.environ.get('GH_TOKEN')
    if pat:
        return pat
    config_path = os.path.expanduser('~/.pr-review')
    if os.path.exists(config_path):
        with open(config_path) as f:
            for line in f:
                line = line.strip()
                if line.startswith('GITHUB_TOKEN='):
                    return line.split('=', 1)[1]
    return None


def fetch_pr_diff(owner: str, repo: str, number: int, pat: Optional[str] = None) -> Optional[str]:
    """Fetch PR diff from GitHub API."""
    url = f'https://api.github.com/repos/{owner}/{repo}/pulls/{number}'
    headers = {
        'Accept': 'application/vnd.github.v3.diff',
        'User-Agent': 'pr-review-agent/1.1',
    }
    if pat:
        headers['Authorization'] = f'token {pat}'

    req = urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            return resp.read().decode('utf-8')
    except urllib.error.HTTPError as e:
        print(f"✗ Error fetching PR: {e.code} {e.reason}", file=sys.stderr)
        if e.code == 404:
            print("  → PR not found. Check URL or permissions.", file=sys.stderr)
        elif e.code == 403:
            print("  → Rate limited or no permission. Set GITHUB_TOKEN env var.", file=sys.stderr)
        return None
    except Exception as e:
        print(f"✗ Network error: {e}", file=sys.stderr)
        return None


# ── AI API ─────────────────────────────────────────────────────────────────────

SUPPORTED_API_KEYS = [
    'AI_API_KEY',
    'OPENAI_API_KEY',
    'DASHSCOPE_API_KEY',
    'DEEPSEEK_API_KEY',
    'NVIDIA_API_KEY',
]

# Known provider presets
PROVIDER_PRESETS = {
    'openai': {
        'base_url': 'https://api.openai.com/v1/chat/completions',
        'model': 'gpt-4o-mini',
        'key_env': 'OPENAI_API_KEY',
    },
    'dashscope': {
        'base_url': 'https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions',
        'model': 'qwen-turbo',
        'key_env': 'DASHSCOPE_API_KEY',
    },
    'deepseek': {
        'base_url': 'https://api.deepseek.com/chat/completions',
        'model': 'deepseek-chat',
        'key_env': 'DEEPSEEK_API_KEY',
    },
    'nous': {
        'base_url': 'https://inference-api.nousresearch.com/v1/chat/completions',
        'model': 'deepseek/deepseek-v4-flash',
        'key_env': 'NVIDIA_API_KEY',
    },
}


def get_api_key(provider: str = None, cli_key: str = None) -> Optional[str]:
    """Find an API key from: CLI arg → provider-specific env → any known env → config file."""
    # 1. CLI arg takes precedence
    if cli_key:
        return cli_key

    # 2. Provider-specific env var
    if provider and provider in PROVIDER_PRESETS:
        key_env = PROVIDER_PRESETS[provider]['key_env']
        val = os.environ.get(key_env)
        if val:
            return val

    # 3. Any known env var
    for key_name in SUPPORTED_API_KEYS:
        val = os.environ.get(key_name)
        if val:
            return val

    # 4. Config file
    config_path = os.path.expanduser('~/.pr-review')
    if os.path.exists(config_path):
        with open(config_path) as f:
            for line in f:
                line = line.strip()
                if line.startswith('AI_API_KEY='):
                    return line.split('=', 1)[1]

    return None


def resolve_api_url(provider: str = None, cli_url: str = None) -> str:
    """Resolve the API URL from: CLI arg → provider preset → env → default."""
    if cli_url:
        return cli_url
    env_url = os.environ.get('AI_API_URL')
    if env_url:
        return env_url
    if provider and provider in PROVIDER_PRESETS:
        return PROVIDER_PRESETS[provider]['base_url']
    return 'https://api.openai.com/v1/chat/completions'


def resolve_model(provider: str = None, cli_model: str = None) -> str:
    """Resolve model name from: CLI arg → env → provider preset → default."""
    if cli_model:
        return cli_model
    env_model = os.environ.get('AI_MODEL')
    if env_model:
        return env_model
    if provider and provider in PROVIDER_PRESETS:
        return PROVIDER_PRESETS[provider]['model']
    return 'gpt-4o-mini'


SYSTEM_PROMPT = """You are a senior code reviewer. Analyze the provided git diff and produce a structured review.

Focus on:
1. **Bug risks** — logic errors, edge cases, race conditions
2. **Security issues** — injection, auth, data exposure
3. **Code quality** — readability, maintainability, naming, duplication
4. **Design/architecture** — separation of concerns, coupling, extensibility

Format your response exactly as:

## Review Summary
(1-2 sentence overview)

## Issues (sorted by severity)

### 🔴 HIGH
- **File:line** — Description. Suggested fix.

### 🟡 MEDIUM
- **File:line** — Description. Suggested fix.

### 🟢 LOW / SUGGESTION
- **File:line** — Description.

## Overall Assessment
- **Changes reviewed**: N files, +N/-N lines
- **Risk level**: Low / Medium / High
- **Ready to merge?**: Yes / Conditional / No

Be direct and specific. Don't add fluff."""


def call_ai_api(diff: str, api_key: str, api_url: str, model: str) -> Optional[str]:
    """Call AI API to analyze the diff."""
    payload = json.dumps({
        "model": model,
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"Review this pull request diff:\n\n```diff\n{diff}\n```"}
        ],
        "temperature": 0.3,
        "max_tokens": 4096,
    }).encode('utf-8')

    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {api_key}',
    }

    req = urllib.request.Request(api_url, data=payload, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=120) as resp:
            result = json.loads(resp.read().decode('utf-8'))
            content = result['choices'][0]['message']['content']
            usage = result.get('usage', {})
            if usage:
                print(f"  [tokens: ↑{usage.get('prompt_tokens','?')} ↓{usage.get('completion_tokens','?')}]", file=sys.stderr)
            return content
    except urllib.error.HTTPError as e:
        body = e.read().decode('utf-8', errors='replace')[:500]
        print(f"✗ AI API error ({e.code}): {body}", file=sys.stderr)
        return None
    except Exception as e:
        print(f"✗ AI API error: {e}", file=sys.stderr)
        return None


# ── CLI ────────────────────────────────────────────────────────────────────────

def parse_changes_summary(diff: str) -> str:
    """Extract a summary of changes from the diff header."""
    files = set()
    added = 0
    removed = 0
    for line in diff.split('\n'):
        if line.startswith('+++ b/'):
            files.add(line[6:])
        elif line.startswith('--- a/'):
            files.add(line[6:])
        elif line.startswith('+') and not line.startswith('+++'):
            added += 1
        elif line.startswith('-') and not line.startswith('---'):
            removed += 1
    return f"{len(files)} files, +{added}/-{removed} lines"


def main():
    # Show available providers in help
    provider_list = ', '.join(PROVIDER_PRESETS.keys())

    parser = argparse.ArgumentParser(
        description='PR Review Agent — AI-powered code review',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f"""
Examples:
  pr-review https://github.com/user/repo/pull/123
  git diff main...feature | pr-review
  pr-review --provider dashscope https://github.com/user/repo/pull/123
  pr-review --model gpt-4o --api-key sk-xxx https://github.com/user/repo/pull/123

Providers: {provider_list}
Model env: AI_MODEL  |  API URL env: AI_API_URL  |  API Key env: AI_API_KEY
        """,
    )
    parser.add_argument('input', nargs='?',
                        help='GitHub PR URL or "-" for stdin diff')
    parser.add_argument('--format', choices=['markdown', 'json', 'text'],
                        default='markdown',
                        help='Output format (default: markdown)')
    parser.add_argument('--provider', choices=list(PROVIDER_PRESETS.keys()),
                        help=f'AI provider preset ({provider_list})')
    parser.add_argument('--api-url',
                        help='AI API endpoint URL (overrides provider preset)')
    parser.add_argument('--api-key',
                        help='API key (overrides env vars)')
    parser.add_argument('--model',
                        help='Model name (overrides env AI_MODEL)')

    args = parser.parse_args()

    # ── Get diff ──────────────────────────────────────────────────────────
    diff = None
    if args.input:
        pr_info = parse_pr_url(args.input)
        if pr_info:
            print(f"  Fetching PR #{pr_info['number']} from {pr_info['owner']}/{pr_info['repo']}...",
                  file=sys.stderr)
            pat = get_pat()
            diff = fetch_pr_diff(pr_info['owner'], pr_info['repo'], pr_info['number'], pat)
            if not diff:
                sys.exit(1)
            print(f"  Got diff: {parse_changes_summary(diff)}", file=sys.stderr)
        elif args.input == '-':
            diff = sys.stdin.read()
        else:
            print("✗ Invalid input. Use 'https://github.com/owner/repo/pull/N' or '-'.", file=sys.stderr)
            sys.exit(1)
    else:
        # Read from stdin (pipe)
        if not sys.stdin.isatty():
            diff = sys.stdin.read()

    if not diff or diff.strip() == '':
        print("✗ No diff to analyze. Pass a PR URL or pipe a git diff.", file=sys.stderr)
        sys.exit(1)

    # ── Configure AI ──────────────────────────────────────────────────────
    api_key = get_api_key(provider=args.provider, cli_key=args.api_key)
    if not api_key:
        print("✗ No API key found.", file=sys.stderr)
        print("  Set one of these env vars:", ', '.join(SUPPORTED_API_KEYS), file=sys.stderr)
        print("  Or create ~/.pr-review with: AI_API_KEY=sk-...", file=sys.stderr)
        print("  Or use --api-key or --provider.", file=sys.stderr)
        sys.exit(1)

    api_url = resolve_api_url(provider=args.provider, cli_url=args.api_url)
    model = resolve_model(provider=args.provider, cli_model=args.model)

    provider_name = args.provider or 'custom'
    print(f"  Using: {model} @ {provider_name}", file=sys.stderr)
    print(f"  Analyzing... (this may take 10-30s)", file=sys.stderr)

    # ── Review ────────────────────────────────────────────────────────────
    review = call_ai_api(diff, api_key, api_url, model)
    if not review:
        sys.exit(1)

    # ── Output ────────────────────────────────────────────────────────────
    if args.format == 'json':
        print(json.dumps({
            "review": review,
            "format": "markdown",
            "model": model,
            "diff_summary": parse_changes_summary(diff),
        }, ensure_ascii=False))
    elif args.format == 'text':
        # Strip markdown formatting for plain text
        text = re.sub(r'[*#`\[\]]', '', review)
        text = re.sub(r'\n{3,}', '\n\n', text)
        print(text.strip())
    else:
        print(review)


if __name__ == '__main__':
    main()

#!/usr/bin/env bash
# PR Review Agent — Setup script
set -e

echo "=== PR Review Agent Setup ==="

# Install dependencies (minimal, just stdlib)
echo "✓ No external dependencies needed (uses Python stdlib)"

# Make executable
chmod +x "$(dirname "$0")/pr_review.py"
echo "✓ Script ready"

# Create config template
CONFIG="$HOME/.pr-review"
if [ ! -f "$CONFIG" ]; then
    cat > "$CONFIG" << 'EOF'
# PR Review Agent Configuration
# Get your API key from https://platform.openai.com/api-keys
AI_API_KEY=sk-your-key-here

# Optional: GitHub Personal Access Token (for private repos)
# GITHUB_TOKEN=ghp_your-token-here

# Optional: Custom API endpoint (OpenAI-compatible)
# AI_API_URL=https://api.openai.com/v1/chat/completions
EOF
    echo "✓ Created ~/.pr-review (edit to add your API key)"
else
    echo "• ~/.pr-review already exists"
fi

# Aliases
echo ""
echo "=== Setup Complete ==="
echo ""
echo "Quick start:"
echo "  1. Edit ~/.pr-review and set your AI_API_KEY"
echo "  2. Run: python3 $(dirname "$0")/pr_review.py https://github.com/owner/repo/pull/123"
echo ""
echo "Or set alias:"
echo "  alias pr-review='python3 $(dirname \"$0\")/pr_review.py'"
